# Quick Start Guide

## Sentinel AI - Fraud Intelligence Platform

Your project is ready to run!

## Setup Instructions

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Development Server
```bash
npm run dev
```

### 3. Open Your Browser
Navigate to: `http://localhost:5173`

## Demo Login Credentials

- **Email**: Use any email (e.g., `analyst@sentinel.ai`)
- **Password**: Use any password
- **OTP**: `123456`

## Available Commands

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server |
| `npm run build` | Build for production |
| `npm run preview` | Preview production build |
| `npm run lint` | Run ESLint |
| `npm run typecheck` | Run TypeScript checks |

## Features Included

- Real-time fraud detection dashboard
- Live transaction monitoring feed
- AI model visualization (Hybrid Autoencoder + XGBoost)
- Interactive charts and analytics
- 8 comprehensive dashboard tabs:
  - Dashboard (Overview & KPIs)
  - Transactions (Live feed)
  - AI Model (Architecture & metrics)
  - Analytics (Advanced insights)
  - Alerts (Fraud notifications)
  - Security (Security overview)
  - Reports (Export capabilities)
  - Settings (Configuration)
- Secure 2FA authentication flow
- Responsive design
- Production-ready build system

## Tech Stack

- **React 18** - UI framework
- **TypeScript** - Type safety
- **Vite** - Build tool and dev server
- **Recharts** - Data visualization library
- **Tailwind CSS** - Utility-first styling
- **Supabase** - Backend infrastructure (pre-configured)

## Build for Production

```bash
npm run build
```

Production files will be generated in the `dist/` folder.

## Project Structure

```
project/
├── src/
│   ├── fintech-dashboard.jsx  # Main dashboard
│   ├── App.tsx                # App component
│   ├── main.tsx               # Entry point
│   └── index.css              # Global styles
├── public/                    # Static assets
├── package.json               # Dependencies
├── vite.config.ts             # Vite configuration
└── README.md                  # Full documentation
```

## Need Help?

Check the full `README.md` for detailed documentation.
