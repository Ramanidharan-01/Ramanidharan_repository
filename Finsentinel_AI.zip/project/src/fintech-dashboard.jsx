import { useState, useEffect, useRef } from "react";
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  RadarChart, Radar, PolarGrid, PolarAngleAxis,
  ScatterChart, Scatter, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PolarRadiusAxis, Cell
} from "recharts";

// ─── MOCK DATA ──────────────────────────────────────────────
const generateTransactions = (n = 40) =>
  Array.from({ length: n }, (_, i) => ({
    id: `TXN-${100000 + i}`,
    time: new Date(Date.now() - i * 180000).toLocaleTimeString(),
    amount: +(Math.random() * 4800 + 10).toFixed(2),
    anomalyScore: +(Math.random()).toFixed(4),
    fraudProb: +(Math.random() * 0.98).toFixed(4),
    status: Math.random() > 0.85 ? "FRAUD" : "NORMAL",
    location: ["Chennai", "Mumbai", "Delhi", "Bangalore", "Hyderabad", "London", "Dubai"][Math.floor(Math.random() * 7)],
    channel: ["Web", "Mobile", "ATM", "POS"][Math.floor(Math.random() * 4)],
    merchant: ["Amazon", "Flipkart", "Netflix", "Swiggy", "Unknown Merchant", "Shell Gas", "Apple Store"][Math.floor(Math.random() * 7)],
    v1: (Math.random() * 4 - 2).toFixed(3),
    v14: (Math.random() * 6 - 3).toFixed(3),
  }));

const riskTimeline = Array.from({ length: 24 }, (_, i) => ({
  hour: `${i}:00`,
  normal: Math.floor(Math.random() * 200 + 50),
  fraud: Math.floor(Math.random() * 20),
  anomaly: +(Math.random() * 0.4 + 0.05).toFixed(3),
}));

const featureImportance = [
  { feature: "V14", importance: 0.312 }, { feature: "V4", importance: 0.289 },
  { feature: "V12", importance: 0.231 }, { feature: "V10", importance: 0.198 },
  { feature: "Amount", importance: 0.176 }, { feature: "V17", importance: 0.154 },
  { feature: "V3", importance: 0.132 }, { feature: "Recon Error", importance: 0.121 },
];

const radarData = [
  { subject: "Velocity", A: 85 }, { subject: "Amount", A: 62 },
  { subject: "Location", A: 40 }, { subject: "Pattern", A: 91 },
  { subject: "Device", A: 55 }, { subject: "Time", A: 73 },
];

const prCurve = Array.from({ length: 20 }, (_, i) => ({
  recall: +(i / 19).toFixed(2),
  precision: +(0.95 - i * 0.03 + Math.random() * 0.04).toFixed(3),
}));

const reconDist = Array.from({ length: 50 }, (_, i) => ({
  error: +(i * 0.1).toFixed(1),
  normal: Math.floor(Math.exp(-((i - 5) ** 2) / 8) * 400 + Math.random() * 20),
  fraud: Math.floor(Math.exp(-((i - 28) ** 2) / 30) * 60 + Math.random() * 5),
}));

// ─── COLORS ─────────────────────────────────────────────────
const C = {
  bg: "#020408",
  surface: "#060d18",
  panel: "#0a1628",
  border: "#0f2a4a",
  accent: "#00d4ff",
  accent2: "#00ff9d",
  danger: "#ff3b6b",
  warn: "#ffb830",
  muted: "#3a5a7a",
  text: "#c8e0f4",
  textDim: "#4a7a9b",
  glow: "0 0 20px rgba(0,212,255,0.15)",
};

// ─── COMPONENTS ─────────────────────────────────────────────
const Card = ({ children, style = {}, className = "" }) => (
  <div style={{
    background: `linear-gradient(135deg, ${C.panel} 0%, #0d1f35 100%)`,
    border: `1px solid ${C.border}`,
    borderRadius: 12,
    padding: "20px 24px",
    boxShadow: C.glow,
    ...style,
  }} className={className}>{children}</div>
);

const Badge = ({ label, type = "normal" }) => {
  const colors = {
    FRAUD: { bg: "rgba(255,59,107,0.15)", color: C.danger, border: C.danger },
    NORMAL: { bg: "rgba(0,255,157,0.1)", color: C.accent2, border: C.accent2 },
    warn: { bg: "rgba(255,184,48,0.1)", color: C.warn, border: C.warn },
  };
  const s = colors[type] || colors.NORMAL;
  return (
    <span style={{
      background: s.bg, color: s.color, border: `1px solid ${s.border}`,
      borderRadius: 6, padding: "2px 10px", fontSize: 11, fontFamily: "monospace",
      fontWeight: 700, letterSpacing: 1,
    }}>{label}</span>
  );
};

const Gauge = ({ value, max = 1, label, color }) => {
  const pct = Math.min(value / max, 1);
  const angle = pct * 180 - 90;
  const r = 60;
  const cx = 80, cy = 80;
  const toRad = deg => deg * Math.PI / 180;
  const arcX = cx + r * Math.cos(toRad(angle - 90));
  const arcY = cy + r * Math.sin(toRad(angle - 90));
  const largeArc = pct > 0.5 ? 1 : 0;

  return (
    <div style={{ textAlign: "center" }}>
      <svg width={160} height={100} viewBox="0 0 160 100">
        <defs>
          <linearGradient id={`g${label}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#00ff9d" />
            <stop offset="50%" stopColor={C.warn} />
            <stop offset="100%" stopColor={C.danger} />
          </linearGradient>
        </defs>
        <path d="M 20 80 A 60 60 0 0 1 140 80" fill="none" stroke={C.border} strokeWidth={10} strokeLinecap="round" />
        <path
          d={`M 20 80 A 60 60 0 ${largeArc} 1 ${arcX} ${arcY}`}
          fill="none" stroke={`url(#g${label})`} strokeWidth={10} strokeLinecap="round"
        />
        <text x={80} y={72} textAnchor="middle" fill={color || C.accent} fontSize={22} fontFamily="monospace" fontWeight="bold">
          {(pct * 100).toFixed(0)}%
        </text>
        <text x={80} y={90} textAnchor="middle" fill={C.textDim} fontSize={10} fontFamily="monospace">{label}</text>
      </svg>
    </div>
  );
};

const StatCard = ({ label, value, sub, icon, accent = C.accent, delta }) => (
  <Card style={{ padding: "18px 22px" }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
      <div>
        <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, textTransform: "uppercase", marginBottom: 6 }}>{label}</div>
        <div style={{ fontSize: 28, fontWeight: 800, color: accent, fontFamily: "monospace" }}>{value}</div>
        {sub && <div style={{ fontSize: 12, color: C.textDim, marginTop: 4 }}>{sub}</div>}
        {delta !== undefined && (
          <div style={{ fontSize: 11, color: delta >= 0 ? C.danger : C.accent2, marginTop: 4 }}>
            {delta >= 0 ? "▲" : "▼"} {Math.abs(delta)}% vs last hour
          </div>
        )}
      </div>
      <div style={{ fontSize: 28, opacity: 0.6 }}>{icon}</div>
    </div>
  </Card>
);

const ThreatMeter = ({ level }) => {
  const levels = ["MINIMAL", "LOW", "MODERATE", "HIGH", "CRITICAL"];
  const colors = [C.accent2, "#80ff9d", C.warn, "#ff8c00", C.danger];
  return (
    <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
      {levels.map((l, i) => (
        <div key={l} style={{
          flex: 1, height: 8, borderRadius: 4,
          background: i <= level ? colors[i] : C.border,
          boxShadow: i <= level ? `0 0 8px ${colors[i]}` : "none",
          transition: "all 0.3s",
        }} />
      ))}
      <span style={{ fontSize: 12, color: colors[level], fontFamily: "monospace", fontWeight: 700, marginLeft: 8, minWidth: 70 }}>
        {levels[level]}
      </span>
    </div>
  );
};

// ─── LOGIN PAGE ──────────────────────────────────────────────
const LoginPage = ({ onLogin }) => {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    setParticles(Array.from({ length: 40 }, (_, i) => ({
      id: i, x: Math.random() * 100, y: Math.random() * 100,
      size: Math.random() * 2 + 0.5, speed: Math.random() * 20 + 10,
      opacity: Math.random() * 0.5 + 0.1,
    })));
  }, []);

  const handleStep1 = () => {
    if (!email || !pass) { setErr("All fields required"); return; }
    setLoading(true); setErr("");
    setTimeout(() => { setLoading(false); setStep(2); }, 1400);
  };

  const handleStep2 = () => {
    if (otp !== "123456") { setErr("Invalid OTP. Use 123456 for demo"); return; }
    setLoading(true); setErr("");
    setTimeout(() => { setLoading(false); onLogin(); }, 1200);
  };

  return (
    <div style={{
      minHeight: "100vh", background: C.bg, display: "flex",
      alignItems: "center", justifyContent: "center",
      fontFamily: "'JetBrains Mono', 'Courier New', monospace",
      overflow: "hidden", position: "relative",
    }}>
      {/* Animated grid background */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `linear-gradient(${C.border} 1px, transparent 1px), linear-gradient(90deg, ${C.border} 1px, transparent 1px)`,
        backgroundSize: "60px 60px", opacity: 0.3,
      }} />
      {/* Particles */}
      {particles.map(p => (
        <div key={p.id} style={{
          position: "absolute", left: `${p.x}%`, top: `${p.y}%`,
          width: p.size, height: p.size, borderRadius: "50%",
          background: C.accent, opacity: p.opacity,
          animation: `float${p.id % 3} ${p.speed}s infinite linear`,
          boxShadow: `0 0 ${p.size * 3}px ${C.accent}`,
        }} />
      ))}
      {/* Glow orbs */}
      <div style={{ position: "absolute", top: "20%", left: "15%", width: 300, height: 300, borderRadius: "50%", background: "radial-gradient(circle, rgba(0,212,255,0.08) 0%, transparent 70%)" }} />
      <div style={{ position: "absolute", bottom: "20%", right: "15%", width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, rgba(255,59,107,0.06) 0%, transparent 70%)" }} />

      <div style={{ position: "relative", zIndex: 10, width: 420 }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 36, marginBottom: 8 }}>🛡️</div>
          <div style={{ fontSize: 24, fontWeight: 900, color: C.accent, letterSpacing: 4, textShadow: `0 0 20px ${C.accent}` }}>
            SENTINEL AI
          </div>
          <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 3, marginTop: 4 }}>
            FRAUD INTELLIGENCE PLATFORM
          </div>
        </div>

        <Card style={{ padding: 36 }}>
          {/* Security indicator */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 28, padding: "8px 12px", background: "rgba(0,255,157,0.06)", border: `1px solid rgba(0,255,157,0.2)`, borderRadius: 8 }}>
            <span style={{ fontSize: 14 }}>🔒</span>
            <span style={{ fontSize: 11, color: C.accent2, letterSpacing: 1 }}>256-BIT TLS · AES ENCRYPTED · ZERO-TRUST</span>
          </div>

          {step === 1 ? (
            <>
              <div style={{ fontSize: 13, color: C.textDim, marginBottom: 24, letterSpacing: 1 }}>SECURE AUTHENTICATION</div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ display: "block", fontSize: 11, color: C.textDim, marginBottom: 6, letterSpacing: 2 }}>EMAIL ADDRESS</label>
                <input value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="analyst@sentinel.ai"
                  style={{ width: "100%", background: "#030912", border: `1px solid ${C.border}`, color: C.text, padding: "12px 14px", borderRadius: 8, fontSize: 13, fontFamily: "inherit", outline: "none", boxSizing: "border-box" }}
                />
              </div>
              <div style={{ marginBottom: 8 }}>
                <label style={{ display: "block", fontSize: 11, color: C.textDim, marginBottom: 6, letterSpacing: 2 }}>PASSWORD</label>
                <input type="password" value={pass} onChange={e => setPass(e.target.value)}
                  placeholder="••••••••••••"
                  style={{ width: "100%", background: "#030912", border: `1px solid ${C.border}`, color: C.text, padding: "12px 14px", borderRadius: 8, fontSize: 13, fontFamily: "inherit", outline: "none", boxSizing: "border-box" }}
                />
              </div>
              {err && <div style={{ color: C.danger, fontSize: 12, marginBottom: 8 }}>{err}</div>}
              <div style={{ fontSize: 11, color: C.textDim, marginBottom: 20, textAlign: "right" }}>Use any email + password for demo</div>
              <button onClick={handleStep1} disabled={loading}
                style={{ width: "100%", background: `linear-gradient(135deg, ${C.accent} 0%, #0099cc 100%)`, color: "#000", border: "none", padding: "14px", borderRadius: 8, fontSize: 14, fontWeight: 800, cursor: "pointer", letterSpacing: 2, fontFamily: "inherit" }}>
                {loading ? "AUTHENTICATING..." : "AUTHENTICATE →"}
              </button>
            </>
          ) : (
            <>
              <div style={{ fontSize: 13, color: C.warn, marginBottom: 8, letterSpacing: 1 }}>🔑 TWO-FACTOR VERIFICATION</div>
              <div style={{ fontSize: 11, color: C.textDim, marginBottom: 20 }}>OTP sent to {email}. Demo OTP: <b style={{ color: C.accent }}>123456</b></div>
              <div style={{ marginBottom: 20 }}>
                <label style={{ display: "block", fontSize: 11, color: C.textDim, marginBottom: 6, letterSpacing: 2 }}>ENTER OTP</label>
                <input value={otp} onChange={e => setOtp(e.target.value)}
                  placeholder="_ _ _ _ _ _" maxLength={6}
                  style={{ width: "100%", background: "#030912", border: `1px solid ${C.warn}`, color: C.text, padding: "14px", borderRadius: 8, fontSize: 22, fontFamily: "inherit", outline: "none", textAlign: "center", letterSpacing: 12, boxSizing: "border-box" }}
                />
              </div>
              {err && <div style={{ color: C.danger, fontSize: 12, marginBottom: 8 }}>{err}</div>}
              <button onClick={handleStep2} disabled={loading}
                style={{ width: "100%", background: `linear-gradient(135deg, ${C.accent2} 0%, #00aa66 100%)`, color: "#000", border: "none", padding: "14px", borderRadius: 8, fontSize: 14, fontWeight: 800, cursor: "pointer", letterSpacing: 2, fontFamily: "inherit" }}>
                {loading ? "VERIFYING..." : "VERIFY & ENTER ✓"}
              </button>
            </>
          )}
        </Card>

        <div style={{ textAlign: "center", marginTop: 16, fontSize: 10, color: C.textDim, letterSpacing: 1 }}>
          SENTINEL AI v3.1 · PROTECTED BY ISO 27001 · GDPR COMPLIANT
        </div>
      </div>

      <style>{`
        @keyframes float0 { 0%{transform:translateY(0)} 50%{transform:translateY(-30px)} 100%{transform:translateY(0)} }
        @keyframes float1 { 0%{transform:translateY(0)} 50%{transform:translateY(20px)} 100%{transform:translateY(0)} }
        @keyframes float2 { 0%{transform:translateX(0)} 50%{transform:translateX(20px)} 100%{transform:translateX(0)} }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        @keyframes scan { 0%{transform:translateY(-100%)} 100%{transform:translateY(100vh)} }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
      `}</style>
    </div>
  );
};

// ─── MAIN DASHBOARD ─────────────────────────────────────────
export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [transactions, setTransactions] = useState(generateTransactions(40));
  const [selectedTxn, setSelectedTxn] = useState(null);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [alertCount, setAlertCount] = useState(3);
  const [modelRunning, setModelRunning] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [csvResult, setCsvResult] = useState(null);
  const [sessionTime, setSessionTime] = useState(0);
  const [showNotif, setShowNotif] = useState(false);
  const [threatLevel, setThreatLevel] = useState(2);
  const [theme, setTheme] = useState("dark");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [liveMonitor, setLiveMonitor] = useState(true);
  const fileRef = useRef();

  // Live feed simulation
  useEffect(() => {
    if (!liveMonitor) return;
    const interval = setInterval(() => {
      setTransactions(prev => {
        const newTxn = generateTransactions(1)[0];
        newTxn.id = `TXN-${Date.now().toString().slice(-6)}`;
        newTxn.time = new Date().toLocaleTimeString();
        if (newTxn.status === "FRAUD") setAlertCount(c => c + 1);
        return [newTxn, ...prev.slice(0, 39)];
      });
    }, 4000);
    return () => clearInterval(interval);
  }, [liveMonitor]);

  // Session timer
  useEffect(() => {
    if (!loggedIn) return;
    const t = setInterval(() => setSessionTime(s => s + 1), 1000);
    return () => clearInterval(t);
  }, [loggedIn]);

  const fraudTxns = transactions.filter(t => t.status === "FRAUD");
  const fraudRate = ((fraudTxns.length / transactions.length) * 100).toFixed(1);
  const avgAnomalyScore = (transactions.reduce((a, b) => a + b.anomalyScore, 0) / transactions.length).toFixed(4);
  const totalAmount = transactions.reduce((a, b) => a + b.amount, 0).toFixed(2);

  const formatTime = s => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  const runModel = () => {
    setModelRunning(true);
    setTimeout(() => {
      setModelRunning(false);
      setCsvResult({
        totalRows: 284807,
        fraudDetected: 492,
        normalTxns: 284315,
        rocAuc: 0.9987,
        prAuc: 0.8312,
        threshold: 0.4721,
        f1: 0.8634,
        precision: 0.9102,
        recall: 0.8211,
      });
    }, 3000);
  };

  if (!loggedIn) return <LoginPage onLogin={() => setLoggedIn(true)} />;

  const navItems = [
    { id: "dashboard", icon: "⬡", label: "DASHBOARD" },
    { id: "transactions", icon: "⇄", label: "TRANSACTIONS" },
    { id: "model", icon: "◈", label: "AI MODEL" },
    { id: "analytics", icon: "◉", label: "ANALYTICS" },
    { id: "alerts", icon: "⚠", label: `ALERTS ${alertCount > 0 ? `(${alertCount})` : ""}` },
    { id: "security", icon: "⊛", label: "SECURITY" },
    { id: "reports", icon: "▦", label: "REPORTS" },
    { id: "settings", icon: "⊕", label: "SETTINGS" },
  ];

  return (
    <div style={{
      minHeight: "100vh", background: C.bg, color: C.text,
      fontFamily: "'JetBrains Mono', 'Courier New', monospace",
      display: "flex", flexDirection: "column", fontSize: 13,
    }}>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: ${C.bg}; }
        ::-webkit-scrollbar-thumb { background: ${C.muted}; border-radius: 2px; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        @keyframes scanline { 0%{transform:translateY(-100%)} 100%{transform:translateY(100%)} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        @keyframes glow { 0%,100%{box-shadow:0 0 5px rgba(0,212,255,0.3)} 50%{box-shadow:0 0 20px rgba(0,212,255,0.7)} }
        @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        .nav-item:hover { background: rgba(0,212,255,0.08) !important; color: ${C.accent} !important; }
        .txn-row:hover { background: rgba(0,212,255,0.04) !important; cursor: pointer; }
        .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
        input:focus { border-color: ${C.accent} !important; box-shadow: 0 0 0 2px rgba(0,212,255,0.1) !important; }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.2} }
      `}</style>

      {/* TOP BAR */}
      <div style={{
        height: 56, background: C.surface, borderBottom: `1px solid ${C.border}`,
        display: "flex", alignItems: "center", padding: "0 20px", gap: 16, zIndex: 100,
        position: "sticky", top: 0,
      }}>
        <button onClick={() => setSidebarOpen(o => !o)} style={{ background: "none", border: "none", color: C.textDim, cursor: "pointer", fontSize: 18 }}>☰</button>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 18 }}>🛡️</span>
          <span style={{ fontWeight: 900, color: C.accent, letterSpacing: 3, fontSize: 14 }}>SENTINEL AI</span>
          <span style={{ fontSize: 10, color: C.textDim, letterSpacing: 2 }}>FRAUD INTELLIGENCE</span>
        </div>
        <div style={{ flex: 1 }} />
        {/* Live indicator */}
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <div style={{ width: 8, height: 8, borderRadius: "50%", background: liveMonitor ? C.accent2 : C.muted, animation: liveMonitor ? "blink 2s infinite" : "none" }} />
          <span style={{ fontSize: 10, color: liveMonitor ? C.accent2 : C.textDim, letterSpacing: 1 }}>{liveMonitor ? "LIVE" : "PAUSED"}</span>
        </div>
        {/* Threat level */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "4px 12px", background: "rgba(255,184,48,0.08)", border: `1px solid rgba(255,184,48,0.2)`, borderRadius: 6 }}>
          <span style={{ fontSize: 10, color: C.warn, letterSpacing: 1 }}>THREAT:</span>
          <ThreatMeter level={threatLevel} />
        </div>
        {/* Session */}
        <div style={{ fontSize: 11, color: C.textDim, fontFamily: "monospace" }}>
          ⏱ {formatTime(sessionTime)}
        </div>
        {/* Alerts */}
        <button onClick={() => { setShowNotif(n => !n); setAlertCount(0); }} style={{ position: "relative", background: "none", border: "none", cursor: "pointer", color: C.textDim, fontSize: 18 }}>
          🔔
          {alertCount > 0 && <span style={{ position: "absolute", top: -4, right: -4, background: C.danger, color: "#fff", borderRadius: "50%", width: 16, height: 16, fontSize: 9, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700 }}>{alertCount}</span>}
        </button>
        {/* Notification dropdown */}
        {showNotif && (
          <div style={{ position: "absolute", top: 60, right: 20, width: 320, background: C.panel, border: `1px solid ${C.border}`, borderRadius: 10, zIndex: 200, padding: 16, animation: "fadeIn 0.2s" }}>
            <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 12 }}>NOTIFICATIONS</div>
            {fraudTxns.slice(0, 4).map((t, i) => (
              <div key={i} style={{ padding: "10px 0", borderBottom: `1px solid ${C.border}`, display: "flex", gap: 10, alignItems: "flex-start" }}>
                <span style={{ color: C.danger, fontSize: 16 }}>⚠</span>
                <div>
                  <div style={{ fontSize: 12, color: C.text }}>Fraud flagged: {t.id}</div>
                  <div style={{ fontSize: 10, color: C.textDim }}>{t.time} · Score {t.fraudProb}</div>
                </div>
              </div>
            ))}
          </div>
        )}
        {/* User */}
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 32, height: 32, borderRadius: "50%", background: `linear-gradient(135deg, ${C.accent} 0%, #0055aa 100%)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>A</div>
          <span style={{ fontSize: 12, color: C.text }}>Analyst</span>
        </div>
        <button onClick={() => setLoggedIn(false)} style={{ background: "none", border: `1px solid ${C.border}`, color: C.textDim, padding: "4px 10px", borderRadius: 6, cursor: "pointer", fontSize: 11, letterSpacing: 1 }}>LOGOUT</button>
      </div>

      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
        {/* SIDEBAR */}
        {sidebarOpen && (
          <div style={{
            width: 200, background: C.surface, borderRight: `1px solid ${C.border}`,
            padding: "20px 0", display: "flex", flexDirection: "column", flexShrink: 0,
          }}>
            {navItems.map(item => (
              <button key={item.id} onClick={() => setActiveTab(item.id)} className="nav-item"
                style={{
                  display: "flex", alignItems: "center", gap: 10, padding: "12px 20px",
                  background: activeTab === item.id ? `rgba(0,212,255,0.1)` : "none",
                  border: "none", color: activeTab === item.id ? C.accent : C.textDim,
                  borderLeft: activeTab === item.id ? `3px solid ${C.accent}` : "3px solid transparent",
                  cursor: "pointer", textAlign: "left", fontSize: 11, letterSpacing: 1.5, fontFamily: "inherit",
                  transition: "all 0.2s",
                }}>
                <span style={{ fontSize: 14 }}>{item.icon}</span>
                {item.label}
              </button>
            ))}
            <div style={{ flex: 1 }} />
            <div style={{ padding: "16px 20px", fontSize: 10, color: C.textDim, lineHeight: 1.8 }}>
              <div>MODEL: XGBoost + AE</div>
              <div style={{ color: C.accent2 }}>ROC-AUC: 0.9987</div>
              <div>LAST TRAINED: 2h ago</div>
            </div>
          </div>
        )}

        {/* MAIN CONTENT */}
        <div style={{ flex: 1, overflow: "auto", padding: 24, animation: "fadeIn 0.3s" }}>

          {/* ── DASHBOARD TAB ── */}
          {activeTab === "dashboard" && (
            <div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
                <div>
                  <div style={{ fontSize: 18, fontWeight: 900, color: C.text, letterSpacing: 2 }}>FRAUD INTELLIGENCE DASHBOARD</div>
                  <div style={{ fontSize: 11, color: C.textDim, marginTop: 4 }}>{new Date().toLocaleString()} · Real-time monitoring active</div>
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <button onClick={() => setLiveMonitor(m => !m)} style={{
                    background: liveMonitor ? "rgba(0,255,157,0.1)" : "rgba(255,59,107,0.1)",
                    border: `1px solid ${liveMonitor ? C.accent2 : C.danger}`,
                    color: liveMonitor ? C.accent2 : C.danger, padding: "8px 16px", borderRadius: 8,
                    cursor: "pointer", fontSize: 11, letterSpacing: 1, fontFamily: "inherit",
                  }}>
                    {liveMonitor ? "⏸ PAUSE FEED" : "▶ RESUME FEED"}
                  </button>
                </div>
              </div>

              {/* KPI CARDS */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 24 }}>
                <StatCard label="Total Transactions" value={transactions.length} sub="Last 40 events" icon="↕" accent={C.accent} delta={5} />
                <StatCard label="Fraud Detected" value={fraudTxns.length} sub={`${fraudRate}% fraud rate`} icon="⚠" accent={C.danger} delta={12} />
                <StatCard label="Avg Anomaly Score" value={avgAnomalyScore} sub="Reconstruction error" icon="◈" accent={C.warn} />
                <StatCard label="Volume Monitored" value={`$${(+totalAmount / 1000).toFixed(1)}K`} sub="Total transaction value" icon="$" accent={C.accent2} delta={-3} />
              </div>

              {/* GAUGES ROW */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 24 }}>
                {[
                  { label: "ROC-AUC", value: 0.9987 },
                  { label: "PR-AUC", value: 0.8312 },
                  { label: "F1 SCORE", value: 0.8634 },
                  { label: "PRECISION", value: 0.9102 },
                ].map(g => (
                  <Card key={g.label} style={{ padding: "16px 10px", textAlign: "center" }}>
                    <Gauge value={g.value} max={1} label={g.label} />
                  </Card>
                ))}
              </div>

              {/* CHARTS ROW */}
              <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16, marginBottom: 24 }}>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>▦ FRAUD vs NORMAL — 24H TIMELINE</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <AreaChart data={riskTimeline}>
                      <defs>
                        <linearGradient id="gNormal" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={C.accent} stopOpacity={0.3} />
                          <stop offset="95%" stopColor={C.accent} stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="gFraud" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={C.danger} stopOpacity={0.5} />
                          <stop offset="95%" stopColor={C.danger} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                      <XAxis dataKey="hour" stroke={C.textDim} tick={{ fontSize: 9 }} interval={3} />
                      <YAxis stroke={C.textDim} tick={{ fontSize: 9 }} />
                      <Tooltip contentStyle={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 8, fontSize: 11 }} />
                      <Area type="monotone" dataKey="normal" stroke={C.accent} fill="url(#gNormal)" strokeWidth={2} />
                      <Area type="monotone" dataKey="fraud" stroke={C.danger} fill="url(#gFraud)" strokeWidth={2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </Card>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>◉ RISK RADAR</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <RadarChart data={radarData}>
                      <PolarGrid stroke={C.border} />
                      <PolarAngleAxis dataKey="subject" tick={{ fill: C.textDim, fontSize: 10 }} />
                      <PolarRadiusAxis tick={false} axisLine={false} />
                      <Radar name="Risk" dataKey="A" stroke={C.danger} fill={C.danger} fillOpacity={0.2} strokeWidth={2} />
                    </RadarChart>
                  </ResponsiveContainer>
                </Card>
              </div>

              {/* ANOMALY SCORE + RECENT FRAUD */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>◈ RECONSTRUCTION ERROR DISTRIBUTION</div>
                  <ResponsiveContainer width="100%" height={180}>
                    <AreaChart data={reconDist}>
                      <defs>
                        <linearGradient id="gN" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={C.accent} stopOpacity={0.4} />
                          <stop offset="95%" stopColor={C.accent} stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="gF" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={C.danger} stopOpacity={0.6} />
                          <stop offset="95%" stopColor={C.danger} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="error" stroke={C.textDim} tick={{ fontSize: 8 }} />
                      <YAxis stroke={C.textDim} tick={{ fontSize: 8 }} />
                      <Tooltip contentStyle={{ background: C.panel, border: `1px solid ${C.border}`, fontSize: 11 }} />
                      <Area dataKey="normal" stroke={C.accent} fill="url(#gN)" strokeWidth={1.5} name="Normal" />
                      <Area dataKey="fraud" stroke={C.danger} fill="url(#gF)" strokeWidth={1.5} name="Fraud" />
                    </AreaChart>
                  </ResponsiveContainer>
                </Card>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 12 }}>⚠ RECENT FRAUD FLAGS</div>
                  <div style={{ overflow: "auto", maxHeight: 200 }}>
                    {fraudTxns.slice(0, 6).map((t, i) => (
                      <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: `1px solid ${C.border}` }}>
                        <div>
                          <div style={{ fontSize: 12, color: C.danger }}>{t.id}</div>
                          <div style={{ fontSize: 10, color: C.textDim }}>{t.merchant} · {t.location}</div>
                        </div>
                        <div style={{ textAlign: "right" }}>
                          <div style={{ fontSize: 12, color: C.text }}>${t.amount}</div>
                          <div style={{ fontSize: 10, color: C.warn }}>Score: {t.fraudProb}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            </div>
          )}

          {/* ── TRANSACTIONS TAB ── */}
          {activeTab === "transactions" && (
            <div>
              <div style={{ fontSize: 16, fontWeight: 900, color: C.text, letterSpacing: 2, marginBottom: 20 }}>⇄ LIVE TRANSACTION FEED</div>
              <div style={{ display: "flex", gap: 12, marginBottom: 16 }}>
                <div style={{ padding: "6px 14px", background: "rgba(0,255,157,0.08)", border: `1px solid ${C.accent2}`, borderRadius: 6, fontSize: 11, color: C.accent2 }}>NORMAL: {transactions.length - fraudTxns.length}</div>
                <div style={{ padding: "6px 14px", background: "rgba(255,59,107,0.08)", border: `1px solid ${C.danger}`, borderRadius: 6, fontSize: 11, color: C.danger }}>FRAUD: {fraudTxns.length}</div>
              </div>
              <Card style={{ padding: 0, overflow: "hidden" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr style={{ background: "#060d18", borderBottom: `1px solid ${C.border}` }}>
                      {["ID", "TIME", "AMOUNT", "MERCHANT", "LOCATION", "CHANNEL", "ANOMALY SCORE", "FRAUD PROB", "STATUS"].map(h => (
                        <th key={h} style={{ padding: "12px 16px", textAlign: "left", fontSize: 10, color: C.textDim, letterSpacing: 1.5, fontWeight: 600 }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((t, i) => (
                      <tr key={t.id} className="txn-row" onClick={() => setSelectedTxn(t)}
                        style={{ borderBottom: `1px solid ${C.border}`, background: t.status === "FRAUD" ? "rgba(255,59,107,0.03)" : "transparent", transition: "background 0.15s" }}>
                        <td style={{ padding: "10px 16px", fontSize: 12, color: C.accent, fontFamily: "monospace" }}>{t.id}</td>
                        <td style={{ padding: "10px 16px", fontSize: 11, color: C.textDim }}>{t.time}</td>
                        <td style={{ padding: "10px 16px", fontSize: 12, color: C.text }}>${t.amount}</td>
                        <td style={{ padding: "10px 16px", fontSize: 11, color: C.text }}>{t.merchant}</td>
                        <td style={{ padding: "10px 16px", fontSize: 11, color: C.textDim }}>{t.location}</td>
                        <td style={{ padding: "10px 16px", fontSize: 11, color: C.textDim }}>{t.channel}</td>
                        <td style={{ padding: "10px 16px" }}>
                          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                            <div style={{ flex: 1, height: 4, background: C.border, borderRadius: 2, overflow: "hidden" }}>
                              <div style={{ width: `${t.anomalyScore * 100}%`, height: "100%", background: t.anomalyScore > 0.7 ? C.danger : t.anomalyScore > 0.4 ? C.warn : C.accent2, borderRadius: 2 }} />
                            </div>
                            <span style={{ fontSize: 11, color: C.textDim, minWidth: 40 }}>{t.anomalyScore}</span>
                          </div>
                        </td>
                        <td style={{ padding: "10px 16px", fontSize: 12, color: t.fraudProb > 0.7 ? C.danger : t.fraudProb > 0.4 ? C.warn : C.accent2, fontFamily: "monospace" }}>{t.fraudProb}</td>
                        <td style={{ padding: "10px 16px" }}><Badge label={t.status} type={t.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>

              {/* Transaction Detail Modal */}
              {selectedTxn && (
                <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 500, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Card style={{ width: 500, animation: "fadeIn 0.2s" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
                      <div style={{ fontSize: 14, fontWeight: 900, color: C.text, letterSpacing: 2 }}>TRANSACTION DETAIL</div>
                      <button onClick={() => setSelectedTxn(null)} style={{ background: "none", border: "none", color: C.textDim, cursor: "pointer", fontSize: 18 }}>×</button>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                      {[
                        ["Transaction ID", selectedTxn.id], ["Status", selectedTxn.status],
                        ["Amount", `$${selectedTxn.amount}`], ["Time", selectedTxn.time],
                        ["Merchant", selectedTxn.merchant], ["Location", selectedTxn.location],
                        ["Channel", selectedTxn.channel], ["Anomaly Score", selectedTxn.anomalyScore],
                        ["Fraud Probability", selectedTxn.fraudProb], ["V1 Feature", selectedTxn.v1],
                        ["V14 Feature", selectedTxn.v14],
                      ].map(([k, v]) => (
                        <div key={k} style={{ padding: "10px 12px", background: "#030912", borderRadius: 6, border: `1px solid ${C.border}` }}>
                          <div style={{ fontSize: 10, color: C.textDim, letterSpacing: 1 }}>{k}</div>
                          <div style={{ fontSize: 13, color: k === "Status" && v === "FRAUD" ? C.danger : C.text, marginTop: 4, fontWeight: k === "Status" ? 700 : 400 }}>{v}</div>
                        </div>
                      ))}
                    </div>
                    <div style={{ marginTop: 16 }}>
                      <div style={{ fontSize: 11, color: C.textDim, marginBottom: 8 }}>ANOMALY SCORE VISUAL</div>
                      <div style={{ height: 12, background: C.border, borderRadius: 6, overflow: "hidden" }}>
                        <div style={{
                          height: "100%",
                          width: `${selectedTxn.anomalyScore * 100}%`,
                          background: `linear-gradient(90deg, ${C.accent2}, ${C.warn}, ${C.danger})`,
                          borderRadius: 6, transition: "width 0.5s",
                        }} />
                      </div>
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: C.textDim, marginTop: 4 }}>
                        <span>NORMAL</span><span>SUSPICIOUS</span><span>FRAUD</span>
                      </div>
                    </div>
                  </Card>
                </div>
              )}
            </div>
          )}

          {/* ── AI MODEL TAB ── */}
          {activeTab === "model" && (
            <div>
              <div style={{ fontSize: 16, fontWeight: 900, color: C.text, letterSpacing: 2, marginBottom: 20 }}>◈ AI MODEL — HYBRID AE + XGBOOST</div>

              {/* Model Architecture */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>MODEL ARCHITECTURE</div>
                  {[
                    { layer: "Input", shape: "30 features", color: C.accent },
                    { layer: "Dense 128 + BN", shape: "ReLU activation", color: C.accent },
                    { layer: "Dense 64", shape: "Encoder layer", color: "#7ad4ff" },
                    { layer: "Latent 32", shape: "Feature compression", color: C.warn },
                    { layer: "Dense 64 → 128", shape: "Decoder", color: "#7ad4ff" },
                    { layer: "Reconstruction", shape: "MSE Loss", color: C.accent },
                    { layer: "Hybrid Features", shape: "X + Latent + Error", color: C.accent2 },
                    { layer: "XGBoost", shape: "900 trees, depth 6", color: C.danger },
                  ].map((l, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
                      <div style={{ width: 8, height: 8, borderRadius: "50%", background: l.color, flexShrink: 0 }} />
                      <div style={{ flex: 1, height: 32, background: `rgba(${l.color === C.accent ? "0,212,255" : "255,184,48"},0.08)`, border: `1px solid ${l.color}22`, borderRadius: 6, display: "flex", alignItems: "center", padding: "0 12px", justifyContent: "space-between" }}>
                        <span style={{ fontSize: 12, color: l.color }}>{l.layer}</span>
                        <span style={{ fontSize: 10, color: C.textDim }}>{l.shape}</span>
                      </div>
                    </div>
                  ))}
                </Card>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>FEATURE IMPORTANCE (XGBoost)</div>
                  <ResponsiveContainer width="100%" height={260}>
                    <BarChart data={featureImportance} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                      <XAxis type="number" stroke={C.textDim} tick={{ fontSize: 9 }} />
                      <YAxis dataKey="feature" type="category" stroke={C.textDim} tick={{ fontSize: 10, fill: C.textDim }} width={70} />
                      <Tooltip contentStyle={{ background: C.panel, border: `1px solid ${C.border}`, fontSize: 11 }} />
                      <Bar dataKey="importance" radius={[0, 4, 4, 0]}>
                        {featureImportance.map((_, i) => (
                          <Cell key={i} fill={`hsl(${190 + i * 12}, 90%, 55%)`} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </Card>
              </div>

              {/* PR Curve + Upload */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>PRECISION–RECALL CURVE</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={prCurve}>
                      <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                      <XAxis dataKey="recall" stroke={C.textDim} tick={{ fontSize: 9 }} label={{ value: "Recall", position: "insideBottom", fill: C.textDim, fontSize: 10, offset: -4 }} />
                      <YAxis stroke={C.textDim} tick={{ fontSize: 9 }} domain={[0, 1]} />
                      <Tooltip contentStyle={{ background: C.panel, border: `1px solid ${C.border}`, fontSize: 11 }} />
                      <Line dataKey="precision" stroke={C.accent} strokeWidth={2.5} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </Card>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>▲ RUN MODEL ON CSV</div>
                  <div style={{ border: `2px dashed ${C.border}`, borderRadius: 10, padding: "30px 20px", textAlign: "center", marginBottom: 16, cursor: "pointer" }}
                    onClick={() => fileRef.current?.click()}>
                    <div style={{ fontSize: 28, marginBottom: 8 }}>📂</div>
                    <div style={{ fontSize: 12, color: C.textDim }}>Upload creditcard.csv</div>
                    {uploadedFile && <div style={{ fontSize: 11, color: C.accent2, marginTop: 6 }}>✓ {uploadedFile.name}</div>}
                  </div>
                  <input ref={fileRef} type="file" accept=".csv" style={{ display: "none" }} onChange={e => setUploadedFile(e.target.files[0])} />
                  <button onClick={runModel} className="btn-primary"
                    style={{ width: "100%", background: `linear-gradient(135deg, ${C.accent} 0%, #0077aa 100%)`, color: "#000", border: "none", padding: 14, borderRadius: 8, fontSize: 13, fontWeight: 800, cursor: "pointer", letterSpacing: 2, fontFamily: "inherit", transition: "all 0.2s" }}>
                    {modelRunning ? (
                      <span style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                        <span style={{ animation: "spin 1s linear infinite", display: "inline-block" }}>◌</span> RUNNING MODEL...
                      </span>
                    ) : "▶ EXECUTE FRAUD DETECTION"}
                  </button>

                  {csvResult && (
                    <div style={{ marginTop: 16, animation: "fadeIn 0.4s" }}>
                      <div style={{ fontSize: 10, color: C.accent2, letterSpacing: 2, marginBottom: 10 }}>✓ MODEL RESULTS</div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                        {[
                          ["Total Rows", csvResult.totalRows.toLocaleString()],
                          ["Fraud Detected", csvResult.fraudDetected],
                          ["ROC-AUC", csvResult.rocAuc],
                          ["PR-AUC", csvResult.prAuc],
                          ["F1 Score", csvResult.f1],
                          ["Optimal Threshold", csvResult.threshold],
                        ].map(([k, v]) => (
                          <div key={k} style={{ padding: "8px 10px", background: "#030912", borderRadius: 6, border: `1px solid ${C.border}` }}>
                            <div style={{ fontSize: 9, color: C.textDim }}>{k}</div>
                            <div style={{ fontSize: 14, color: C.accent, fontFamily: "monospace", fontWeight: 700 }}>{v}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </Card>
              </div>
            </div>
          )}

          {/* ── ANALYTICS TAB ── */}
          {activeTab === "analytics" && (
            <div>
              <div style={{ fontSize: 16, fontWeight: 900, color: C.text, letterSpacing: 2, marginBottom: 20 }}>◉ ADVANCED ANALYTICS</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>FRAUD BY CHANNEL</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={[
                      { channel: "Web", count: 18 }, { channel: "Mobile", count: 7 },
                      { channel: "ATM", count: 12 }, { channel: "POS", count: 3 },
                    ]}>
                      <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                      <XAxis dataKey="channel" stroke={C.textDim} tick={{ fontSize: 10 }} />
                      <YAxis stroke={C.textDim} tick={{ fontSize: 9 }} />
                      <Tooltip contentStyle={{ background: C.panel, border: `1px solid ${C.border}`, fontSize: 11 }} />
                      <Bar dataKey="count" fill={C.danger} radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </Card>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>ANOMALY SCORE TIMELINE</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={riskTimeline}>
                      <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                      <XAxis dataKey="hour" stroke={C.textDim} tick={{ fontSize: 9 }} interval={4} />
                      <YAxis stroke={C.textDim} tick={{ fontSize: 9 }} />
                      <Tooltip contentStyle={{ background: C.panel, border: `1px solid ${C.border}`, fontSize: 11 }} />
                      <Line dataKey="anomaly" stroke={C.warn} strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </Card>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>TRANSACTION VOLUME SCATTER</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <ScatterChart>
                      <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                      <XAxis dataKey="x" name="Amount" stroke={C.textDim} tick={{ fontSize: 9 }} />
                      <YAxis dataKey="y" name="Score" stroke={C.textDim} tick={{ fontSize: 9 }} />
                      <Tooltip contentStyle={{ background: C.panel, border: `1px solid ${C.border}`, fontSize: 11 }} cursor={{ strokeDasharray: "3 3" }} />
                      <Scatter data={transactions.slice(0, 30).map(t => ({ x: t.amount, y: +t.fraudProb }))} fill={C.accent} fillOpacity={0.7} />
                    </ScatterChart>
                  </ResponsiveContainer>
                </Card>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>FRAUD RATE BY LOCATION</div>
                  {["Chennai", "Mumbai", "Delhi", "Bangalore", "London", "Dubai"].map((loc, i) => {
                    const rate = [12, 8, 22, 6, 31, 18][i];
                    return (
                      <div key={loc} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                        <div style={{ minWidth: 80, fontSize: 11, color: C.textDim }}>{loc}</div>
                        <div style={{ flex: 1, height: 6, background: C.border, borderRadius: 3, overflow: "hidden" }}>
                          <div style={{ width: `${rate}%`, height: "100%", background: rate > 20 ? C.danger : rate > 10 ? C.warn : C.accent2, borderRadius: 3 }} />
                        </div>
                        <div style={{ fontSize: 11, color: C.text, minWidth: 30 }}>{rate}%</div>
                      </div>
                    );
                  })}
                </Card>
              </div>
            </div>
          )}

          {/* ── ALERTS TAB ── */}
          {activeTab === "alerts" && (
            <div>
              <div style={{ fontSize: 16, fontWeight: 900, color: C.text, letterSpacing: 2, marginBottom: 20 }}>⚠ FRAUD ALERTS</div>
              <div style={{ marginBottom: 16 }}>
                <ThreatMeter level={threatLevel} />
                <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
                  {[0, 1, 2, 3, 4].map(l => (
                    <button key={l} onClick={() => setThreatLevel(l)}
                      style={{ padding: "4px 10px", background: threatLevel === l ? "rgba(0,212,255,0.15)" : "none", border: `1px solid ${C.border}`, color: C.textDim, borderRadius: 6, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>
                      L{l}
                    </button>
                  ))}
                  <span style={{ fontSize: 10, color: C.textDim, alignSelf: "center", marginLeft: 4 }}>Simulate threat level</span>
                </div>
              </div>
              {fraudTxns.map((t, i) => (
                <Card key={i} style={{ marginBottom: 12, borderLeft: `3px solid ${C.danger}`, padding: "14px 20px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div>
                      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
                        <span style={{ color: C.danger, fontSize: 16 }}>⚠</span>
                        <span style={{ fontSize: 13, color: C.danger, fontWeight: 700 }}>FRAUD DETECTED</span>
                        <Badge label="HIGH RISK" type="FRAUD" />
                      </div>
                      <div style={{ fontSize: 12, color: C.text }}>Transaction {t.id} flagged by AI model</div>
                      <div style={{ fontSize: 11, color: C.textDim, marginTop: 4 }}>
                        {t.merchant} · {t.location} · {t.channel} · ${t.amount}
                      </div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 12, color: C.warn }}>Fraud Prob: {t.fraudProb}</div>
                      <div style={{ fontSize: 10, color: C.textDim, marginTop: 4 }}>{t.time}</div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}

          {/* ── SECURITY TAB ── */}
          {activeTab === "security" && (
            <div>
              <div style={{ fontSize: 16, fontWeight: 900, color: C.text, letterSpacing: 2, marginBottom: 20 }}>⊛ SECURITY OVERVIEW</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 20 }}>
                {[
                  { label: "SSL/TLS", status: "ACTIVE", icon: "🔒", color: C.accent2 },
                  { label: "2FA", status: "ENABLED", icon: "📱", color: C.accent2 },
                  { label: "IP WHITELIST", status: "ENFORCED", icon: "🌐", color: C.accent2 },
                  { label: "RATE LIMITING", status: "ON", icon: "⚡", color: C.accent2 },
                  { label: "DARK WEB MONITOR", status: "SCANNING", icon: "🕵️", color: C.warn },
                  { label: "ANOMALY ENGINE", status: "RUNNING", icon: "◈", color: C.accent2 },
                ].map(s => (
                  <Card key={s.label} style={{ display: "flex", alignItems: "center", gap: 14 }}>
                    <span style={{ fontSize: 24 }}>{s.icon}</span>
                    <div>
                      <div style={{ fontSize: 10, color: C.textDim, letterSpacing: 2 }}>{s.label}</div>
                      <div style={{ fontSize: 13, color: s.color, fontWeight: 700 }}>{s.status}</div>
                    </div>
                    <div style={{ marginLeft: "auto", width: 8, height: 8, borderRadius: "50%", background: s.color, animation: "blink 2s infinite" }} />
                  </Card>
                ))}
              </div>
              <Card>
                <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>SECURITY EVENT LOG</div>
                {[
                  { time: "14:23:01", event: "Login successful — 2FA verified", type: "info" },
                  { time: "14:22:58", event: "OTP generated and dispatched", type: "info" },
                  { time: "14:20:44", event: "High anomaly score detected: TXN-100012 (0.9821)", type: "warn" },
                  { time: "14:18:11", event: "Fraud flagged — auto-blocked: TXN-100007", type: "danger" },
                  { time: "14:15:02", event: "Model re-evaluated: 3 new patterns identified", type: "info" },
                  { time: "14:10:33", event: "API rate limit hit from IP 203.0.113.0", type: "warn" },
                  { time: "14:05:00", event: "Session started — access level: ANALYST", type: "info" },
                ].map((e, i) => (
                  <div key={i} style={{ display: "flex", gap: 16, padding: "8px 0", borderBottom: `1px solid ${C.border}`, alignItems: "flex-start" }}>
                    <span style={{ fontSize: 10, color: C.textDim, minWidth: 70, fontFamily: "monospace" }}>{e.time}</span>
                    <span style={{ fontSize: 10, marginTop: 1 }}>
                      {e.type === "danger" ? "🔴" : e.type === "warn" ? "🟡" : "🔵"}
                    </span>
                    <span style={{ fontSize: 12, color: e.type === "danger" ? C.danger : e.type === "warn" ? C.warn : C.text }}>{e.event}</span>
                  </div>
                ))}
              </Card>
            </div>
          )}

          {/* ── REPORTS TAB ── */}
          {activeTab === "reports" && (
            <div>
              <div style={{ fontSize: 16, fontWeight: 900, color: C.text, letterSpacing: 2, marginBottom: 20 }}>▦ REPORTS & EXPORTS</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
                {[
                  { title: "Fraud Summary Report", desc: "Full fraud analysis for last 30 days", icon: "📊", format: "PDF" },
                  { title: "Transaction Export", desc: "All flagged transactions with scores", icon: "📋", format: "CSV" },
                  { title: "Model Performance", desc: "ROC-AUC, PR-AUC, F1 metrics report", icon: "◈", format: "PDF" },
                  { title: "Anomaly Heatmap", desc: "Visual anomaly distribution map", icon: "🗺️", format: "PNG" },
                  { title: "Compliance Report", desc: "ISO 27001 & GDPR compliance log", icon: "🛡️", format: "PDF" },
                  { title: "Security Audit Log", desc: "Full event log export", icon: "🔒", format: "JSON" },
                ].map(r => (
                  <Card key={r.title} style={{ cursor: "pointer" }}>
                    <div style={{ fontSize: 28, marginBottom: 10 }}>{r.icon}</div>
                    <div style={{ fontSize: 13, color: C.text, fontWeight: 700, marginBottom: 6 }}>{r.title}</div>
                    <div style={{ fontSize: 11, color: C.textDim, marginBottom: 12 }}>{r.desc}</div>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <Badge label={r.format} type="NORMAL" />
                      <button style={{ background: "none", border: `1px solid ${C.border}`, color: C.accent, padding: "4px 12px", borderRadius: 6, cursor: "pointer", fontSize: 11, fontFamily: "inherit" }}>↓ Export</button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* ── SETTINGS TAB ── */}
          {activeTab === "settings" && (
            <div>
              <div style={{ fontSize: 16, fontWeight: 900, color: C.text, letterSpacing: 2, marginBottom: 20 }}>⊕ PLATFORM SETTINGS</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>MODEL PARAMETERS</div>
                  {[
                    { label: "Detection Threshold", value: "0.4721", editable: true },
                    { label: "Scale Pos Weight", value: "0.7 (focal)", editable: true },
                    { label: "Max Depth", value: "6", editable: true },
                    { label: "Learning Rate", value: "0.03", editable: true },
                    { label: "N Estimators", value: "900", editable: false },
                  ].map(p => (
                    <div key={p.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: `1px solid ${C.border}` }}>
                      <span style={{ fontSize: 12, color: C.textDim }}>{p.label}</span>
                      <span style={{ fontSize: 13, color: p.editable ? C.accent : C.text, fontFamily: "monospace" }}>{p.value}</span>
                    </div>
                  ))}
                </Card>
                <Card>
                  <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 2, marginBottom: 16 }}>ALERT CONFIGURATION</div>
                  {[
                    { label: "Email Alerts", enabled: true },
                    { label: "SMS Alerts", enabled: false },
                    { label: "Slack Webhook", enabled: true },
                    { label: "Auto-block Fraud", enabled: false },
                    { label: "Live Feed", enabled: liveMonitor },
                  ].map(s => (
                    <div key={s.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: `1px solid ${C.border}` }}>
                      <span style={{ fontSize: 12, color: C.textDim }}>{s.label}</span>
                      <div style={{
                        width: 36, height: 18, borderRadius: 9, background: s.enabled ? C.accent2 : C.muted,
                        cursor: "pointer", position: "relative", transition: "background 0.2s",
                      }}>
                        <div style={{ position: "absolute", top: 3, left: s.enabled ? 20 : 3, width: 12, height: 12, borderRadius: "50%", background: "#fff", transition: "left 0.2s" }} />
                      </div>
                    </div>
                  ))}
                </Card>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* STATUS BAR */}
      <div style={{
        height: 28, background: "#030810", borderTop: `1px solid ${C.border}`,
        display: "flex", alignItems: "center", padding: "0 20px", gap: 24,
        fontSize: 10, color: C.textDim, letterSpacing: 1,
      }}>
        <span style={{ color: C.accent2, animation: "blink 2s infinite" }}>● CONNECTED</span>
        <span>MODEL: XGBoost + Autoencoder Hybrid</span>
        <span>DATASET: creditcard.csv · 284,807 rows</span>
        <span>AUC: 0.9987</span>
        <div style={{ flex: 1 }} />
        <span>SESSION: {formatTime(sessionTime)}</span>
        <span>SENTINEL AI v3.1</span>
      </div>
    </div>
  );
}
