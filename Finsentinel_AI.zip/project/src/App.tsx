import FintechDashboard from './fintech-dashboard';

function App() {
  return <FintechDashboard />;
}

export default App;
