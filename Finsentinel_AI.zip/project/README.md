# Sentinel AI - Fraud Intelligence Platform

A sophisticated fintech fraud detection dashboard built with React, TypeScript, and Recharts. Features a real-time transaction monitoring system with AI-powered fraud detection analytics.

## Features

- Real-time transaction monitoring with live feed
- AI Model visualization (Hybrid Autoencoder + XGBoost)
- Advanced analytics and fraud detection metrics
- Interactive charts and data visualizations
- Multi-tab dashboard with comprehensive views
- Secure authentication with 2FA simulation
- Responsive design with modern UI

## Quick Start

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn

### Installation

1. Extract the project files
2. Install dependencies:
```bash
npm install
```

### Development

Run the development server:
```bash
npm run dev
```

The application will open at `http://localhost:5173`

### Demo Credentials

- **Login**: Use any email and password
- **OTP**: `123456`

### Build for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

### Preview Production Build

```bash
npm run preview
```

## Tech Stack

- **React 18** - UI framework
- **TypeScript** - Type safety
- **Vite** - Build tool and dev server
- **Recharts** - Data visualization
- **Tailwind CSS** - Styling
- **Supabase** - Backend infrastructure (pre-configured)

## Project Structure

```
├── src/
│   ├── fintech-dashboard.jsx  # Main dashboard component
│   ├── App.tsx                # App entry point
│   ├── main.tsx               # React entry point
│   └── index.css              # Global styles
├── public/                    # Static assets
├── index.html                 # HTML template
└── package.json               # Dependencies
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint
- `npm run typecheck` - Run TypeScript type checking

## Dashboard Tabs

1. **Dashboard** - Overview with KPIs, charts, and real-time metrics
2. **Transactions** - Live transaction feed with fraud detection
3. **AI Model** - Model architecture and performance metrics
4. **Analytics** - Advanced fraud analytics
5. **Alerts** - Fraud alert management
6. **Security** - Security overview and event logs
7. **Reports** - Export capabilities
8. **Settings** - Platform configuration

## License

This project is provided as-is for demonstration purposes.
