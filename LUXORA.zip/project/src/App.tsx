import { useState, useEffect } from 'react';
import { supabase } from './lib/supabase';
import { useAuth } from './contexts/AuthContext';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import HomePage from './pages/HomePage';
import AuthModal from './components/auth/AuthModal';
import CartSidebar from './components/cart/CartSidebar';

interface CartItem {
  id: string;
  product: {
    id: string;
    name: string;
    price: number;
    images: string[];
  };
  quantity: number;
}

function App() {
  const { user } = useAuth();
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadUserData();
    } else {
      loadLocalCart();
      setLoading(false);
    }
  }, [user]);

  const loadUserData = async () => {
    if (!user) return;

    try {
      const [cartRes, wishlistRes] = await Promise.all([
        supabase
          .from('cart_items')
          .select(`
            id,
            quantity,
            product:products (
              id,
              name,
              price,
              images
            )
          `)
          .eq('user_id', user.id),
        supabase
          .from('wishlist')
          .select('product_id')
          .eq('user_id', user.id),
      ]);

      if (cartRes.data) {
        setCart(cartRes.data.map(item => ({
          id: item.id,
          product: item.product as any,
          quantity: item.quantity,
        })));
      }

      if (wishlistRes.data) {
        setWishlist(wishlistRes.data.map(item => item.product_id));
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadLocalCart = () => {
    const saved = localStorage.getItem('cart');
    if (saved) {
      setCart(JSON.parse(saved));
    }
  };

  const saveLocalCart = (newCart: CartItem[]) => {
    localStorage.setItem('cart', JSON.stringify(newCart));
  };

  const handleAddToCart = async (productId: string) => {
    if (!user) {
      setAuthModalOpen(true);
      return;
    }

    try {
      const { data: product } = await supabase
        .from('products')
        .select('id, name, price, images')
        .eq('id', productId)
        .single();

      if (!product) return;

      const existingItem = cart.find(item => item.product.id === productId);

      if (existingItem) {
        await supabase
          .from('cart_items')
          .update({ quantity: existingItem.quantity + 1 })
          .eq('id', existingItem.id);

        setCart(cart.map(item =>
          item.product.id === productId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        ));
      } else {
        const { data: newItem } = await supabase
          .from('cart_items')
          .insert({
            user_id: user.id,
            product_id: productId,
            quantity: 1,
          })
          .select()
          .single();

        if (newItem) {
          setCart([...cart, {
            id: newItem.id,
            product,
            quantity: 1,
          }]);
        }
      }

      setCartOpen(true);
    } catch (error) {
      console.error('Error adding to cart:', error);
    }
  };

  const handleUpdateQuantity = async (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) {
      handleRemoveItem(itemId);
      return;
    }

    if (user) {
      await supabase
        .from('cart_items')
        .update({ quantity: newQuantity })
        .eq('id', itemId);
    }

    setCart(cart.map(item =>
      item.id === itemId ? { ...item, quantity: newQuantity } : item
    ));

    if (!user) {
      saveLocalCart(cart.map(item =>
        item.id === itemId ? { ...item, quantity: newQuantity } : item
      ));
    }
  };

  const handleRemoveItem = async (itemId: string) => {
    if (user) {
      await supabase
        .from('cart_items')
        .delete()
        .eq('id', itemId);
    }

    const newCart = cart.filter(item => item.id !== itemId);
    setCart(newCart);

    if (!user) {
      saveLocalCart(newCart);
    }
  };

  const handleToggleWishlist = async (productId: string) => {
    if (!user) {
      setAuthModalOpen(true);
      return;
    }

    try {
      if (wishlist.includes(productId)) {
        await supabase
          .from('wishlist')
          .delete()
          .eq('user_id', user.id)
          .eq('product_id', productId);

        setWishlist(wishlist.filter(id => id !== productId));
      } else {
        await supabase
          .from('wishlist')
          .insert({
            user_id: user.id,
            product_id: productId,
          });

        setWishlist([...wishlist, productId]);
      }
    } catch (error) {
      console.error('Error toggling wishlist:', error);
    }
  };

  const handleCheckout = () => {
    if (!user) {
      setAuthModalOpen(true);
      return;
    }
    alert('Checkout functionality coming soon!');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#0F172A] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar
        onLoginClick={() => setAuthModalOpen(true)}
        onCartClick={() => setCartOpen(true)}
        cartItemsCount={cart.length}
      />

      <main className="flex-1">
        <HomePage
          onAddToCart={handleAddToCart}
          onToggleWishlist={handleToggleWishlist}
          wishlist={wishlist}
        />
      </main>

      <Footer />

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
      />

      <CartSidebar
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={handleCheckout}
      />
    </div>
  );
}

export default App;
