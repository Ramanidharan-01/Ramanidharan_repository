import { useState } from 'react';
import { ShoppingCart, User, Heart, Menu, X, Search } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../ui/Button';

interface NavbarProps {
  onLoginClick: () => void;
  onCartClick: () => void;
  cartItemsCount: number;
}

export default function Navbar({ onLoginClick, onCartClick, cartItemsCount }: NavbarProps) {
  const { user, signOut } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-8">
            <button
              onClick={() => window.location.href = '/'}
              className="text-2xl font-bold text-[#0F172A] tracking-tight hover:opacity-80 transition-opacity"
            >
              LUXORA
            </button>

            <div className="hidden md:flex items-center gap-6">
              <button className="text-[#0F172A] hover:text-[#22C55E] transition-colors font-medium">
                Home
              </button>
              <button className="text-[#0F172A] hover:text-[#22C55E] transition-colors font-medium">
                Shop
              </button>
              <button className="text-[#0F172A] hover:text-[#22C55E] transition-colors font-medium">
                Categories
              </button>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <Search className="w-5 h-5 text-[#0F172A]" />
            </button>

            {user && (
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative">
                <Heart className="w-5 h-5 text-[#0F172A]" />
              </button>
            )}

            <button
              onClick={onCartClick}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative"
            >
              <ShoppingCart className="w-5 h-5 text-[#0F172A]" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#22C55E] text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItemsCount}
                </span>
              )}
            </button>

            {user ? (
              <div className="flex items-center gap-2">
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                  <User className="w-5 h-5 text-[#0F172A]" />
                </button>
                <Button variant="secondary" size="sm" onClick={signOut}>
                  Sign Out
                </Button>
              </div>
            ) : (
              <Button size="sm" onClick={onLoginClick}>
                Sign In
              </Button>
            )}
          </div>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-[#0F172A]" />
            ) : (
              <Menu className="w-6 h-6 text-[#0F172A]" />
            )}
          </button>
        </div>

        {searchOpen && (
          <div className="pb-4">
            <input
              type="search"
              placeholder="Search products..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F172A]/10"
              autoFocus
            />
          </div>
        )}
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden border-t border-gray-200 pb-4">
          <div className="px-4 pt-4 space-y-3">
            <button className="block w-full text-left px-4 py-2 text-[#0F172A] hover:bg-gray-100 rounded-lg">
              Home
            </button>
            <button className="block w-full text-left px-4 py-2 text-[#0F172A] hover:bg-gray-100 rounded-lg">
              Shop
            </button>
            <button className="block w-full text-left px-4 py-2 text-[#0F172A] hover:bg-gray-100 rounded-lg">
              Categories
            </button>
            {!user && (
              <Button fullWidth onClick={onLoginClick}>
                Sign In
              </Button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
