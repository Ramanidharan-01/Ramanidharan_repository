import { Heart, ShoppingCart, Star } from 'lucide-react';
import Card from '../ui/Card';

interface Product {
  id: string;
  name: string;
  slug: string;
  price: number;
  compare_at_price?: number | null;
  images: string[];
  rating: number;
  reviews_count: number;
  stock: number;
}

interface ProductCardProps {
  product: Product;
  onAddToCart: (productId: string) => void;
  onToggleWishlist: (productId: string) => void;
  isInWishlist: boolean;
}

export default function ProductCard({ product, onAddToCart, onToggleWishlist, isInWishlist }: ProductCardProps) {
  const discount = product.compare_at_price
    ? Math.round(((product.compare_at_price - product.price) / product.compare_at_price) * 100)
    : 0;

  return (
    <Card hover>
      <div className="relative">
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-64 object-cover"
        />
        {discount > 0 && (
          <span className="absolute top-3 left-3 bg-[#EF4444] text-white px-3 py-1 rounded-full text-sm font-semibold">
            -{discount}%
          </span>
        )}
        <button
          onClick={() => onToggleWishlist(product.id)}
          className={`absolute top-3 right-3 p-2 rounded-full transition-all duration-200 ${
            isInWishlist
              ? 'bg-[#EF4444] text-white'
              : 'bg-white/90 text-gray-700 hover:bg-white'
          }`}
        >
          <Heart className={`w-5 h-5 ${isInWishlist ? 'fill-current' : ''}`} />
        </button>

        {product.stock === 0 && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <span className="bg-white px-4 py-2 rounded-lg font-semibold">Out of Stock</span>
          </div>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-lg text-[#0F172A] mb-2 line-clamp-2 hover:text-[#22C55E] transition-colors cursor-pointer">
          {product.name}
        </h3>

        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="ml-1 text-sm font-medium">{product.rating.toFixed(1)}</span>
          </div>
          <span className="text-sm text-gray-500">({product.reviews_count} reviews)</span>
        </div>

        <div className="flex items-center gap-2 mb-4">
          <span className="text-2xl font-bold text-[#0F172A]">
            ${product.price.toFixed(2)}
          </span>
          {product.compare_at_price && (
            <span className="text-lg text-gray-400 line-through">
              ${product.compare_at_price.toFixed(2)}
            </span>
          )}
        </div>

        <button
          onClick={() => onAddToCart(product.id)}
          disabled={product.stock === 0}
          className="w-full bg-[#0F172A] text-white py-2.5 rounded-lg font-medium
            hover:bg-[#1E293B] active:scale-95 transition-all duration-200
            disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <ShoppingCart className="w-5 h-5" />
          Add to Cart
        </button>
      </div>
    </Card>
  );
}
