import { useEffect, useState } from 'react';
import { ArrowRight, TrendingUp, Shield, Truck, Star } from 'lucide-react';
import { supabase } from '../lib/supabase';
import ProductCard from '../components/product/ProductCard';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

interface Category {
  id: string;
  name: string;
  slug: string;
  image_url: string | null;
}

interface Product {
  id: string;
  name: string;
  slug: string;
  price: number;
  compare_at_price: number | null;
  images: string[];
  rating: number;
  reviews_count: number;
  stock: number;
}

interface HomePageProps {
  onAddToCart: (productId: string) => void;
  onToggleWishlist: (productId: string) => void;
  wishlist: string[];
}

export default function HomePage({ onAddToCart, onToggleWishlist, wishlist }: HomePageProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [categoriesRes, productsRes] = await Promise.all([
        supabase.from('categories').select('*').limit(6),
        supabase.from('products').select('*').eq('is_featured', true).limit(8),
      ]);

      if (categoriesRes.data) setCategories(categoriesRes.data);
      if (productsRes.data) setFeaturedProducts(productsRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <section className="relative h-[600px] bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#334155] text-white overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/1884584/pexels-photo-1884584.jpeg?auto=compress&cs=tinysrgb&w=1920')] bg-cover bg-center opacity-20"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="max-w-2xl animate-in fade-in slide-in-from-left duration-700">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Modern Shopping,
              <span className="block text-[#22C55E]">Beautifully Crafted</span>
            </h1>
            <p className="text-xl mb-8 text-gray-300 leading-relaxed">
              Discover premium products curated just for you. Experience the perfect blend of quality, style, and affordability.
            </p>
            <div className="flex gap-4">
              <Button size="lg" variant="primary" className="bg-[#22C55E] hover:bg-[#16A34A]">
                Shop Now
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#0F172A]">
                Explore Categories
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-[#22C55E]/10 rounded-lg">
                <Truck className="w-8 h-8 text-[#22C55E]" />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-[#0F172A]">Free Shipping</h3>
                <p className="text-sm text-gray-600">On orders over $50</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="p-3 bg-[#22C55E]/10 rounded-lg">
                <Shield className="w-8 h-8 text-[#22C55E]" />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-[#0F172A]">Secure Payment</h3>
                <p className="text-sm text-gray-600">100% secure transactions</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="p-3 bg-[#22C55E]/10 rounded-lg">
                <TrendingUp className="w-8 h-8 text-[#22C55E]" />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-[#0F172A]">Best Prices</h3>
                <p className="text-sm text-gray-600">Competitive pricing guaranteed</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-[#0F172A] mb-4">Shop by Category</h2>
            <p className="text-gray-600 text-lg">Explore our curated collections</p>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-white rounded-lg h-48 animate-pulse"></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
              {categories.map((category) => (
                <Card key={category.id} hover className="cursor-pointer group">
                  <div className="relative h-32 overflow-hidden">
                    <img
                      src={category.image_url || 'https://images.pexels.com/photos/1884584/pexels-photo-1884584.jpeg?auto=compress&cs=tinysrgb&w=400'}
                      alt={category.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-4 text-center">
                    <h3 className="font-semibold text-[#0F172A] group-hover:text-[#22C55E] transition-colors">
                      {category.name}
                    </h3>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-4xl font-bold text-[#0F172A] mb-4">Featured Products</h2>
              <p className="text-gray-600 text-lg">Handpicked favorites just for you</p>
            </div>
            <Button variant="outline">
              View All
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="bg-gray-200 rounded-lg h-96 animate-pulse"></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={onAddToCart}
                  onToggleWishlist={onToggleWishlist}
                  isInWishlist={wishlist.includes(product.id)}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="py-16 bg-gradient-to-br from-[#22C55E] to-[#16A34A] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">Customer Reviews</h2>
              <p className="text-lg mb-8 text-green-50">See what our customers are saying</p>

              <div className="space-y-6">
                <Card className="p-6 bg-white/95">
                  <div className="flex items-center gap-2 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4">
                    "Excellent quality products and fast shipping! The customer service was outstanding. Highly recommended!"
                  </p>
                  <p className="font-semibold text-[#0F172A]">Sarah Johnson</p>
                </Card>

                <Card className="p-6 bg-white/95">
                  <div className="flex items-center gap-2 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4">
                    "Love the modern design and easy checkout process. Will definitely shop here again!"
                  </p>
                  <p className="font-semibold text-[#0F172A]">Michael Chen</p>
                </Card>
              </div>
            </div>

            <div className="relative h-96 rounded-lg overflow-hidden">
              <img
                src="https://images.pexels.com/photos/5632402/pexels-photo-5632402.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Happy customer"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-[#0F172A] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Join Our Newsletter</h2>
          <p className="text-xl text-gray-300 mb-8">
            Get exclusive offers, new product updates, and style inspiration delivered to your inbox.
          </p>
          <div className="flex gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-6 py-3 rounded-lg text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#22C55E]"
            />
            <Button size="lg" className="bg-[#22C55E] hover:bg-[#16A34A]">
              Subscribe
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
