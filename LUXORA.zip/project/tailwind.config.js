/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        heading: ['Poppins', 'sans-serif'],
      },
      colors: {
        primary: '#0F172A',
        secondary: '#F8FAFC',
        accent: '#22C55E',
        muted: '#94A3B8',
      },
    },
  },
  plugins: [],
};
